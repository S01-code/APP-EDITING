
document.querySelector('.toggle-theme').addEventListener('click', () => {
  document.body.classList.toggle('dark');
});
